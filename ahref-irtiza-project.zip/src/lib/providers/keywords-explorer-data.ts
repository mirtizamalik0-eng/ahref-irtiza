export interface KeywordOverviewDto {
  keyword: string;
  countryCode: string;
  searchVolume: number;
  keywordDifficulty: number;
  estRefDomainsNeeded: number;
  cpcCents: number;
  trafficPotential: number;
  serpOverview: Array<{
    position: number;
    title: string;
    domain: string;
    domainScore: number;
    referringDomains: number;
    estimatedTraffic: number;
  }>;
}

export async function getKeywordOverview(params: {
  keyword: string;
  countryCode: string;
}): Promise<KeywordOverviewDto> {
  return {
    keyword: params.keyword,
    countryCode: params.countryCode,
    searchVolume: 24500,
    keywordDifficulty: 48,
    estRefDomainsNeeded: 35,
    cpcCents: 420,
    trafficPotential: 31200,
    serpOverview: [
      {
        position: 1,
        title: `The Ultimate Guide to ${params.keyword} in 2026`,
        domain: "authoritative-blog.io",
        domainScore: 84,
        referringDomains: 142,
        estimatedTraffic: 14200,
      },
      {
        position: 2,
        title: `How to Master ${params.keyword} Step-by-Step`,
        domain: "saas-playbook.com",
        domainScore: 78,
        referringDomains: 95,
        estimatedTraffic: 8900,
      },
    ],
  };
}