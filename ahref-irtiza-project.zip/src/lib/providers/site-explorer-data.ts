export interface SiteExplorerOverviewDto {
  target: string;
  domainScore: number;
  pageScore: number;
  referringDomains: number;
  dofollowReferringDomains: number;
  totalBacklinks: number;
  organicTraffic: number;
  organicKeywords: number;
  trafficValueCents: number;
}

export interface BacklinkItemDto {
  id: string;
  sourceUrl: string;
  sourceTitle: string;
  sourceDomainScore: number;
  anchorText: string;
  linkType: "dofollow" | "nofollow";
}

export function cleanTargetDomain(input: string): string {
  return input.replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0].toLowerCase().trim();
}

export async function getSiteExplorerOverview(params: {
  target: string;
  scopeMode: string;
  country: string;
}): Promise<SiteExplorerOverviewDto> {
  const clean = cleanTargetDomain(params.target);
  return {
    target: clean,
    domainScore: 89,
    pageScore: 72,
    referringDomains: 14820,
    dofollowReferringDomains: 12400,
    totalBacklinks: 84920,
    organicTraffic: 342000,
    organicKeywords: 64200,
    trafficValueCents: 12500000,
  };
}

export function buildBacklinksList(cleanTarget: string): BacklinkItemDto[] {
  return [
    {
      id: "bl_1",
      sourceUrl: `https://techcrunch.com/2026/review-${cleanTarget}`,
      sourceTitle: `Why Engineering Teams Are Switching to ${cleanTarget} for Infrastructure`,
      sourceDomainScore: 91,
      anchorText: "official documentation",
      linkType: "dofollow",
    },
    {
      id: "bl_2",
      sourceUrl: `https://smashingmagazine.com/2026/dev-tools-${cleanTarget}`,
      sourceTitle: `Top Developer Tools & APIs Reviewed for 2026`,
      sourceDomainScore: 86,
      anchorText: cleanTarget,
      linkType: "dofollow",
    },
  ];
}